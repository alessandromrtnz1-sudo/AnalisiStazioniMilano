"""
app.py – Monitoraggio Qualità dell'Aria di Milano
Applicazione Streamlit che analizza 10 anni di dati ARPA.
"""

import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import seaborn as sns
import json
from pathlib import Path

# ── Configurazione pagina ──────────────────────────────────────────────────────
st.set_page_config(
    page_title="Qualità dell'Aria – Milano",
    page_icon="🌬️",
    layout="wide",
)

# ── 1. DESCRIZIONE INQUINANTI ──────────────────────────────────────────────────
INQUINANTI_INFO = {
    "NO2": {
        "nome": "Biossido di azoto (NO₂)",
        "cos_e": "Gas rossastro prodotto dalla combustione: traffico (soprattutto diesel), riscaldamento e industria.",
        "pericoloso": "Irrita le vie respiratorie, aggrava asma e bronchiti. L'OMS fissa il limite annuale a 10 µg/m³.",
        "colore": "#e74c3c",
    },
    "PM10": {
        "nome": "Particolato PM10",
        "cos_e": "Particelle con diametro ≤ 10 µm: polveri stradali, scarichi, cantieri e pollini.",
        "pericoloso": "Si depositano nelle vie aeree superiori causando infiammazioni e peggiorando malattie cardiache.",
        "colore": "#e67e22",
    },
    "PM25": {
        "nome": "Particolato PM2.5",
        "cos_e": "Particelle finissime (≤ 2,5 µm) generate da combustioni incomplete e reazioni chimiche in atmosfera.",
        "pericoloso": "Penetrano fino agli alveoli e nel circolo sanguigno: aumentano il rischio di ictus e infarto.",
        "colore": "#8e44ad",
    },
    "O3": {
        "nome": "Ozono (O₃)",
        "cos_e": "Gas secondario formato dalla reazione di NOₓ e COV con la luce solare.",
        "pericoloso": "Irrita occhi e polmoni, riduce la capacità respiratoria. Più alto in estate e in periferia.",
        "colore": "#27ae60",
    },
    "SO2": {
        "nome": "Biossido di zolfo (SO₂)",
        "cos_e": "Gas pungente prodotto dalla combustione di combustibili fossili ricchi di zolfo.",
        "pericoloso": "Causa broncocostrizione acuta; contribuisce alle piogge acide.",
        "colore": "#2980b9",
    },
    "C6H6": {
        "nome": "Benzene (C₆H₆)",
        "cos_e": "Idrocarburo aromatico presente nei carburanti e nei fumi di scarico.",
        "pericoloso": "Cancerogeno accertato (gruppo 1 IARC); danneggia il midollo osseo.",
        "colore": "#16a085",
    },
    "CO_8h": {
        "nome": "Monossido di carbonio – media 8h (CO)",
        "cos_e": "Gas inodore prodotto da combustioni incomplete (traffico, stufe a legna).",
        "pericoloso": "Si lega all'emoglobina impedendo il trasporto di ossigeno; ad alte dosi è letale.",
        "colore": "#7f8c8d",
    },
}

"""
app.py – Monitoraggio Qualità dell'Aria di Milano
Applicazione Streamlit che analizza 10 anni di dati ARPA.
"""

# ──────────────────────────────────────────────────────────────────────────────
# IMPORTAZIONE LIBRERIE
# Queste sono le "cassette degli attrezzi" che usiamo nel programma.
# Senza di esse il codice non funziona.
# ──────────────────────────────────────────────────────────────────────────────

import streamlit as st        # Crea l'interfaccia web (bottoni, grafici, titoli...)
import pandas as pd           # Gestisce le tabelle di dati (come Excel ma in Python)
import matplotlib.pyplot as plt  # Disegna i grafici
import matplotlib.ticker as ticker  # Serve per formattare i numeri sugli assi dei grafici
import seaborn as sns         # Libreria grafica aggiuntiva (non usata attivamente ma importata)
import json                   # Legge i file JSON (il formato dei nostri dati)
from pathlib import Path      # Gestisce i percorsi delle cartelle in modo intelligente

# ──────────────────────────────────────────────────────────────────────────────
# CONFIGURAZIONE DELLA PAGINA
# Queste impostazioni definiscono come appare la finestra del browser.
# Va messo PRIMA di qualsiasi altra cosa Streamlit.
# ──────────────────────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="Qualità dell'Aria – Milano",  # Titolo che appare nel tab del browser
    page_icon="🌬️",                           # Icona nel tab del browser
    layout="wide",                             # Usa tutta la larghezza dello schermo
)

# ──────────────────────────────────────────────────────────────────────────────
# DIZIONARIO DEGLI INQUINANTI
# Un dizionario è come una rubrica: per ogni nome (es. "NO2") troviamo
# le sue informazioni (descrizione, perché è pericoloso, colore del grafico).
# ──────────────────────────────────────────────────────────────────────────────

INQUINANTI_INFO = {

    # -- Inquinante 1: Biossido di Azoto --
    "NO2": {
        "nome": "Biossido di azoto (NO₂)",
        "cos_e": "Gas rossastro prodotto dalla combustione: traffico (soprattutto diesel), riscaldamento e industria.",
        "pericoloso": "Irrita le vie respiratorie, aggrava asma e bronchiti. L'OMS fissa il limite annuale a 10 µg/m³.",
        "colore": "#e74c3c",  # Rosso
    },

    # -- Inquinante 2: Particolato grosso --
    "PM10": {
        "nome": "Particolato PM10",
        "cos_e": "Particelle con diametro ≤ 10 µm: polveri stradali, scarichi, cantieri e pollini.",
        "pericoloso": "Si depositano nelle vie aeree superiori causando infiammazioni e peggiorando malattie cardiache.",
        "colore": "#e67e22",  # Arancione
    },

    # -- Inquinante 3: Particolato fine --
    "PM25": {
        "nome": "Particolato PM2.5",
        "cos_e": "Particelle finissime (≤ 2,5 µm) generate da combustioni incomplete e reazioni chimiche in atmosfera.",
        "pericoloso": "Penetrano fino agli alveoli e nel circolo sanguigno: aumentano il rischio di ictus e infarto.",
        "colore": "#8e44ad",  # Viola
    },

    # -- Inquinante 4: Ozono --
    "O3": {
        "nome": "Ozono (O₃)",
        "cos_e": "Gas secondario formato dalla reazione di NOₓ e COV con la luce solare.",
        "pericoloso": "Irrita occhi e polmoni, riduce la capacità respiratoria. Più alto in estate e in periferia.",
        "colore": "#27ae60",  # Verde
    },

    # -- Inquinante 5: Biossido di Zolfo --
    "SO2": {
        "nome": "Biossido di zolfo (SO₂)",
        "cos_e": "Gas pungente prodotto dalla combustione di combustibili fossili ricchi di zolfo.",
        "pericoloso": "Causa broncocostrizione acuta; contribuisce alle piogge acide.",
        "colore": "#2980b9",  # Blu
    },

    # -- Inquinante 6: Benzene --
    "C6H6": {
        "nome": "Benzene (C₆H₆)",
        "cos_e": "Idrocarburo aromatico presente nei carburanti e nei fumi di scarico.",
        "pericoloso": "Cancerogeno accertato (gruppo 1 IARC); danneggia il midollo osseo.",
        "colore": "#16a085",  # Verde acqua
    },

    # -- Inquinante 7: Monossido di Carbonio --
    "CO_8h": {
        "nome": "Monossido di carbonio – media 8h (CO)",
        "cos_e": "Gas inodore prodotto da combustioni incomplete (traffico, stufe a legna).",
        "pericoloso": "Si lega all'emoglobina impedendo il trasporto di ossigeno; ad alte dosi è letale.",
        "colore": "#7f8c8d",  # Grigio
    },
}

# ──────────────────────────────────────────────────────────────────────────────
# FUNZIONE DI CARICAMENTO DATI
# @st.cache_data = "ricorda" il risultato così non rilegge tutto ogni volta
# che l'utente clicca qualcosa → l'app è più veloce
# ──────────────────────────────────────────────────────────────────────────────

@st.cache_data(show_spinner="Caricamento dati in corso…")
def load_data():

    # Cerca la cartella "dati" in più posti possibili.
    # Questo evita errori se l'utente lancia l'app da cartelle diverse.
    possibili = [
        Path(__file__).parent / "dati",  # Cartella "dati" accanto ad app.py  ← caso normale
        Path(__file__).parent,           # Stessa cartella di app.py (se i JSON sono lì)
        Path.cwd() / "dati",             # Cartella "dati" nella posizione corrente del terminale
        Path.cwd(),                      # Posizione corrente del terminale (ultimo tentativo)
    ]

    base = None  # "base" è la cartella dati che useremo, ancora non la conosciamo

    # Proviamo ogni percorso finché non ne troviamo uno con file JSON dentro
    for p in possibili:
        if p.exists() and list(p.glob("*.json")):  # .glob cerca file con estensione .json
            base = p   # Trovato! Salviamo il percorso
            break      # Usciamo dal ciclo, non serve cercare oltre

    # Se non abbiamo trovato nessuna cartella con dati, mostriamo errore e fermiamo tutto
    if base is None:
        st.error("❌ Cartella dati non trovata! Metti i file JSON nella cartella 'dati/' accanto ad app.py")
        st.stop()  # Blocca l'esecuzione dell'app

    # ── CARICAMENTO STAZIONI ──────────────────────────────────────────────────
    # Apriamo il file GeoJSON che contiene le posizioni fisiche delle stazioni.
    # Usiamo questo file perché contiene TUTTI gli ID corretti (da 1 a 9),
    # mentre il vecchio stazioni_aria.json aveva ID sbagliati.

    geo_path = base / "qaria_stazione.geojson"  # Percorso completo del file
    with open(geo_path, encoding="utf-8") as f:  # Apriamo il file (utf-8 per le lettere accentate)
        geo = json.load(f)                        # Leggiamo il contenuto e lo salviamo in "geo"

    # Creiamo una lista vuota dove metteremo le info di ogni stazione
    stazioni_rows = []

    # Per ogni stazione nel file GeoJSON...
    for feat in geo["features"]:
        p = feat["properties"]            # Le proprietà: nome, id, ecc.
        coords = feat["geometry"]["coordinates"]  # Le coordinate: [longitudine, latitudine]

        # Aggiungiamo alla lista un "dizionario" con le info della stazione
        stazioni_rows.append({
            "stazione_id":   str(p["id_amat"]),  # ID come testo (es. "1", "2"...)
            "nome_stazione": p["nome"],           # Nome leggibile (es. "via Pascal")
            "lon":           coords[0],           # Longitudine (posizione est-ovest)
            "lat":           coords[1],           # Latitudine (posizione nord-sud)
        })

    # Trasformiamo la lista in una tabella pandas (come un foglio Excel)
    df_stazioni = pd.DataFrame(stazioni_rows)

    # ── CARICAMENTO MISURAZIONI ───────────────────────────────────────────────
    # Questi file vanno SALTATI perché non contengono misurazioni di inquinanti
    skip = {"stazioni_aria.json", "qaria_stazione.geojson"}

    # "seen_hashes" è come un registro: memorizza i file già letti
    # per non caricare due volte lo stesso (es. il file 2021 era duplicato!)
    seen_hashes: set = set()

    # Lista dove accumuleremo le tabelle di ogni anno
    lista_df = []

    # Scorriamo tutti i file .json nella cartella dati, in ordine alfabetico
    for fpath in sorted(base.glob("*.json")):

        # Se il file è nella lista "skip", lo ignoriamo e passiamo al prossimo
        if fpath.name in skip:
            continue

        # "try" = proviamo. Se qualcosa va storto, andiamo all'"except" senza bloccare tutto
        try:
            # Apriamo e leggiamo il file JSON
            with open(fpath, encoding="utf-8") as f:
                raw = json.load(f)

            # Trasformiamo il JSON in una tabella
            temp = pd.DataFrame(raw)

            # I file di anni diversi usano nomi di colonne diversi.
            # Le rinominiamo tutte uguali così il codice funziona per tutti gli anni.
            temp = temp.rename(columns={
                "id_stazione":      "stazione_id",   # Vecchio nome → nuovo nome standard
                "codice_stazione":  "stazione_id",
                "data_riferimento": "data",
                "data_misura":      "data",
                "valore_misura":    "valore",
                "inquinante_nome":  "inquinante",
            })

            # Controlliamo che il file abbia almeno le 4 colonne fondamentali.
            # Se ne manca anche solo una, saltiamo questo file.
            if not {"stazione_id", "data", "valore", "inquinante"}.issubset(temp.columns):
                continue

            # Teniamo solo le 4 colonne che ci servono (le altre le buttiamo)
            temp = temp[["stazione_id", "data", "valore", "inquinante"]].copy()

            # Pulizia dei dati:
            temp["stazione_id"] = temp["stazione_id"].astype(str)
            # ↑ Rendiamo l'ID sempre testo. Senza questo "1" (testo) ≠ 1 (numero) → nessun match!

            temp["valore"] = pd.to_numeric(temp["valore"], errors="coerce")
            # ↑ Rendiamo il valore sempre un numero. Se c'è qualcosa di strano → NaN (dato mancante)

            temp["data"] = pd.to_datetime(temp["data"], errors="coerce")
            # ↑ Rendiamo la data un vero oggetto-data che Python capisce come calendario

            # Creiamo una "firma" unica del file: numero righe + data minima + data massima
            # Se due file hanno la stessa firma = sono identici → saltiamo il secondo
            key = (len(temp), str(temp["data"].min()), str(temp["data"].max()))
            if key in seen_hashes:
                continue       # File già caricato, lo saltiamo
            seen_hashes.add(key)  # Registriamo la firma per non ricaricare in futuro

            # Tutto ok! Aggiungiamo la tabella alla lista
            lista_df.append(temp)

        except Exception as e:
            # Se qualcosa è andato storto (file corrotto, formato strano...),
            # mostriamo un avviso giallo nell'app ma continuiamo con gli altri file
            st.warning(f"Errore nel file {fpath.name}: {e}")

    # Se non abbiamo caricato neanche un file, restituiamo "niente" (None)
    if not lista_df:
        return None, None

    # ── PULIZIA E UNIONE FINALE ───────────────────────────────────────────────

    # Uniamo tutte le tabelle annuali in UN'UNICA grande tabella
    df = pd.concat(lista_df, ignore_index=True)
    # ignore_index=True = rinumera le righe da 0 in poi (evita indici duplicati)

    # Rimuoviamo le righe dove manca la data O il valore (dati inutilizzabili)
    df = df.dropna(subset=["data", "valore"])

    # Estraiamo l'anno dalla data: da "2020-03-15" prendiamo solo "2020"
    df["anno"] = df["data"].dt.year

    # UNIONE MISURAZIONI ↔ STAZIONI
    # Colleghiamo la tabella dei dati con quella delle stazioni tramite l'ID.
    # "inner" = teniamo solo le righe dove l'ID esiste in ENTRAMBE le tabelle.
    df_merged = pd.merge(df, df_stazioni, on="stazione_id", how="inner")

    # Restituiamo due tabelle: quella completa e quella delle sole stazioni
    return df_merged, df_stazioni


# ──────────────────────────────────────────────────────────────────────────────
# INTESTAZIONE DELL'APP
# Le prime cose che vede l'utente quando apre la pagina
# ──────────────────────────────────────────────────────────────────────────────

# Titolo grande in cima alla pagina
st.title("🌬️ Monitoraggio della Qualità dell'Aria – Milano")

# Piccolo testo descrittivo sotto al titolo
st.caption(
    "Dati ARPA Lombardia / Comune di Milano • 2016-2025 • "
    "Stazioni di rilevamento comunali"
)

# ──────────────────────────────────────────────────────────────────────────────
# CARICAMENTO EFFETTIVO DEI DATI
# Chiamiamo la funzione definita sopra e salviamo i risultati
# ──────────────────────────────────────────────────────────────────────────────

df, df_stazioni = load_data()  # Eseguiamo la funzione e prendiamo le due tabelle

# Se non ci sono dati (funzione ha restituito None), mostriamo errore e blocchiamo
if df is None:
    st.error(
        "⚠️ Nessun dato trovato. Assicurati che i file JSON siano nella "
        "cartella `dati/` accanto ad `app.py`."
    )
    st.stop()

# ──────────────────────────────────────────────────────────────────────────────
# BARRA LATERALE (SIDEBAR) CON I FILTRI
# La sidebar è il pannello a sinistra dell'app con i menù di selezione
# ──────────────────────────────────────────────────────────────────────────────

st.sidebar.header("🔧 Filtri")  # Titoletto nella barra laterale

# Prendiamo tutti gli inquinanti presenti nei dati, in ordine alfabetico
inquinanti_disponibili = sorted(df["inquinante"].unique())

# Menù a tendina per scegliere l'inquinante. Di default mostra NO2 se disponibile.
inq = st.sidebar.selectbox(
    "Inquinante",
    inquinanti_disponibili,
    index=inquinanti_disponibili.index("NO2") if "NO2" in inquinanti_disponibili else 0
)

# Prendiamo tutte le stazioni presenti nei dati, in ordine alfabetico
stazioni_disponibili = sorted(df["nome_stazione"].unique())

# Menù a tendina per scegliere la stazione
staz = st.sidebar.selectbox("Stazione", stazioni_disponibili)

# Linea separatrice nella sidebar
st.sidebar.markdown("---")

# Piccola nota informativa nella sidebar (riquadro azzurro)
st.sidebar.info(
    "I dati provengono dalle stazioni ARPA collocate nel territorio comunale di Milano. "
    "Non tutte le stazioni sono attive per tutti gli anni."
)

# ══════════════════════════════════════════════════════════════════════════════
# SEZIONE 1 – SPIEGAZIONE DEGLI INQUINANTI
# Mostra una scheda colorata con la descrizione dell'inquinante scelto
# e una tabella riassuntiva di tutti gli inquinanti
# ══════════════════════════════════════════════════════════════════════════════

st.header("📖 Cosa stai monitorando?")

# Cerchiamo le info sull'inquinante selezionato nel dizionario definito sopra
info = INQUINANTI_INFO.get(inq)

if info:  # Se abbiamo trovato le info (quasi sempre sì)

    # Dividiamo la pagina in 2 colonne: sinistra (1 parte) e destra (2 parti)
    col_a, col_b = st.columns([1, 2])

    with col_a:  # Colonna sinistra: scheda colorata dell'inquinante scelto
        st.markdown(
            f"""
            <div style="background:{info['colore']}22;border-left:6px solid {info['colore']};
                        padding:16px;border-radius:8px;">
                <h4 style="margin:0;color:{info['colore']}">{info['nome']}</h4>
                <p><strong>Cos'è:</strong> {info['cos_e']}</p>
                <p><strong>Perché è pericoloso:</strong> {info['pericoloso']}</p>
            </div>
            """,
            unsafe_allow_html=True,  # Permette l'uso di codice HTML colorato
        )

    with col_b:  # Colonna destra: tabella riassuntiva di tutti gli inquinanti
        st.markdown("**Riepilogo inquinanti monitorati**")

        # Costruiamo una lista di righe, una per ogni inquinante nel dizionario
        rows = [
            {
                "Codice": k,                              # Es. "NO2"
                "Nome": v["nome"].split("(")[0].strip(),  # Es. "Biossido di azoto" (senza la formula)
                "Principale fonte": v["cos_e"][:60] + "…" # Primi 60 caratteri della descrizione
            }
            for k, v in INQUINANTI_INFO.items()  # Ciclo su tutti gli inquinanti
        ]

        # Mostriamo la tabella nell'app (hide_index=True = nasconde i numeri di riga)
        st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)

else:
    # Se l'inquinante non ha una scheda nel dizionario, avvisiamo l'utente
    st.info(f"Nessuna scheda descrittiva disponibile per **{inq}**.")

# Linea divisoria orizzontale tra le sezioni
st.divider()

# ══════════════════════════════════════════════════════════════════════════════
# SEZIONE 2 – ANDAMENTO ANNUALE (10 ANNI)
# Grafico che mostra come è cambiato l'inquinante nel tempo
# ══════════════════════════════════════════════════════════════════════════════

st.header(f"📈 Andamento annuale – {inq} (tutte le stazioni)")

# Filtriamo solo le righe dell'inquinante selezionato
df_inq = df[df["inquinante"] == inq]

# Calcoliamo per ogni anno: media, minimo e massimo del valore
df_annuale = (
    df_inq.groupby("anno")["valore"]           # Raggruppiamo per anno
    .agg(["mean", "min", "max"])               # Calcoliamo le 3 statistiche
    .reset_index()                             # Torniamo a una tabella normale
    .rename(columns={"mean": "Media", "min": "Min", "max": "Max"})  # Rinominiamo
)

if df_annuale.empty:
    # Se non ci sono dati per questo inquinante, avvisiamo
    st.warning("Nessun dato disponibile per questo inquinante.")
else:
    # Dividiamo in 2 colonne: grafico grande a sinistra, tabellina a destra
    col1, col2 = st.columns([3, 1])

    with col1:  # Colonna sinistra: GRAFICO TEMPORALE
        fig, ax = plt.subplots(figsize=(10, 4))  # Creiamo il "foglio" del grafico

        # Prendiamo il colore dell'inquinante dal dizionario (o blu di default)
        color = INQUINANTI_INFO.get(inq, {}).get("colore", "#3498db")

        # Area colorata semitrasparente tra il valore minimo e massimo di ogni anno
        ax.fill_between(df_annuale["anno"], df_annuale["Min"], df_annuale["Max"],
                        alpha=0.15, color=color, label="Intervallo Min-Max")

        # Linea della media annuale con pallini sui punti
        ax.plot(df_annuale["anno"], df_annuale["Media"],
                marker="o", color=color, linewidth=2.5, label="Media annuale")

        ax.set_xlabel("Anno")           # Etichetta asse X
        ax.set_ylabel("µg/m³")          # Etichetta asse Y (microgrammi per metro cubo)
        ax.set_title(f"Concentrazione media annuale di {inq} – Milano")  # Titolo grafico
        ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))  # Solo anni interi sull'asse X
        ax.legend()                     # Mostra la legenda (Min-Max / Media)
        ax.grid(axis="y", alpha=0.3)   # Griglia orizzontale leggera

        st.pyplot(fig)   # Mostra il grafico nell'app
        plt.close()      # Libera la memoria (buona pratica)

    with col2:  # Colonna destra: TABELLINA con i valori medi per anno
        st.markdown("**Media per anno (µg/m³)**")
        st.dataframe(
            df_annuale[["anno", "Media"]]       # Solo le colonne anno e media
            .set_index("anno")                  # Anno diventa l'indice (colonna sinistra)
            .style.format({"Media": "{:.1f}"}), # Mostriamo un solo decimale
            width="stretch",
        )

    # Calcolo automatico del trend: confrontiamo ultimo anno con primo anno
    trend = df_annuale["Media"].iloc[-1] - df_annuale["Media"].iloc[0]
    # .iloc[-1] = ultimo valore della colonna, .iloc[0] = primo valore

    # Anno con la media più alta in assoluto
    anno_peggiore = df_annuale.loc[df_annuale["Media"].idxmax(), "anno"]

    # Riquadro azzurro con il commento automatico sul trend
    st.info(
        f"📊 **Trend:** {'📉 In diminuzione' if trend < 0 else '📈 In aumento'} "
        f"di {abs(trend):.1f} µg/m³ dal {df_annuale['anno'].min()} al {df_annuale['anno'].max()}. "
        f"L'anno con il valore medio più alto è stato il **{anno_peggiore}**."
    )

st.divider()

# ══════════════════════════════════════════════════════════════════════════════
# SEZIONE 3 – CLASSIFICA DELLE STAZIONI
# Ordina le stazioni dalla più inquinata alla meno inquinata
# ══════════════════════════════════════════════════════════════════════════════

st.header(f"🏭 Stazioni più critiche – {inq} (media 10 anni)")

# Per ogni stazione calcoliamo la media di tutti gli anni disponibili,
# poi ordiniamo dalla più alta alla più bassa (ascending=False = decrescente)
df_classifica = (
    df_inq.groupby("nome_stazione")["valore"]
    .mean()
    .sort_values(ascending=False)
    .reset_index()
    .rename(columns={"valore": "Media µg/m³"})
)

# Arrotondiamo a 2 decimali per leggibilità
df_classifica["Media µg/m³"] = df_classifica["Media µg/m³"].round(2)

# Impostiamo l'indice a partire da 1 (invece di 0) → la classifica parte da "1°"
df_classifica.index = range(1, len(df_classifica) + 1)

if df_classifica.empty:
    st.warning("Nessuna stazione ha dati validi per questo inquinante.")
else:
    # Dividiamo in 2 colonne: tabella a sinistra, grafico a destra
    col3, col4 = st.columns([1, 2])

    with col3:  # Colonna sinistra: TABELLA CLASSIFICA COMPLETA
        st.markdown("**Classifica completa**")
        st.dataframe(df_classifica, width="stretch")

    with col4:  # Colonna destra: GRAFICO A BARRE ORIZZONTALI (top 5)
        top5 = df_classifica.head(5)  # Prendiamo solo le prime 5 stazioni

        fig2, ax2 = plt.subplots(figsize=(7, 3.5))

        # Grafico a barre orizzontali (barh = horizontal bar)
        bars = ax2.barh(
            top5["nome_stazione"],   # Nomi stazioni sull'asse Y
            top5["Media µg/m³"],     # Valori sull'asse X
            color=INQUINANTI_INFO.get(inq, {}).get("colore", "#e74c3c"),
            edgecolor="white"        # Bordo bianco tra le barre
        )

        ax2.invert_yaxis()  # Mette la stazione più inquinata IN ALTO (più intuitivo)
        ax2.set_xlabel("µg/m³")
        ax2.set_title(f"Top 5 stazioni più critiche – {inq}")
        ax2.bar_label(bars, fmt="%.1f", padding=3)  # Mostra il valore numerico su ogni barra
        ax2.grid(axis="x", alpha=0.3)

        plt.tight_layout()  # Aggiusta automaticamente i margini per non tagliare le etichette
        st.pyplot(fig2)
        plt.close()

st.divider()

# ══════════════════════════════════════════════════════════════════════════════
# SEZIONE 4 – ANDAMENTO GIORNALIERO DELL'ANNO SCELTO
# Mostra il dettaglio giorno per giorno per la stazione e l'inquinante scelti
# ══════════════════════════════════════════════════════════════════════════════

st.header(f"📅 Andamento giornaliero – {inq} @ {staz}")

# Filtriamo i dati per la stazione E l'inquinante scelti nella sidebar
subset = df[(df["nome_stazione"] == staz) & (df["inquinante"] == inq)]

if subset.empty:
    # Se questa stazione non ha dati per questo inquinante, avvisiamo l'utente
    st.warning(
        f"⚠️ La stazione **{staz}** non ha dati per **{inq}**. "
        "Prova a selezionare una stazione o un inquinante diverso dalla barra laterale."
    )
else:
    # Troviamo l'anno più recente disponibile per questa stazione
    ultimo_anno = int(subset["anno"].max())

    # Lista di tutti gli anni disponibili, dal più recente al più vecchio
    anni_disponibili = sorted(subset["anno"].unique(), reverse=True)

    # Menù per scegliere l'anno da visualizzare (di default mostra il più recente)
    anno_scelto = st.selectbox(
        "Anno da visualizzare",
        anni_disponibili,
        index=0,  # Seleziona il primo della lista = il più recente
        format_func=lambda x: f"{x} {'(più recente)' if x == ultimo_anno else ''}"
        # ↑ Aggiunge "(più recente)" accanto all'anno più recente nel menù
    )

    # Filtriamo solo i dati dell'anno scelto, ordinati per data
    df_plot = subset[subset["anno"] == anno_scelto].sort_values("data")

    # ── TRE METRICHE RAPIDE IN CIMA ──────────────────────────────────────────
    col5, col6, col7 = st.columns(3)

    # Media dell'anno
    col5.metric("Media annuale", f"{df_plot['valore'].mean():.1f} µg/m³")

    # Valore massimo + data in cui si è verificato
    col6.metric(
        "Valore massimo",
        f"{df_plot['valore'].max():.1f} µg/m³",
        f"il {df_plot.loc[df_plot['valore'].idxmax(), 'data'].strftime('%d/%m')}"
        # .strftime('%d/%m') = formatta la data come "15/01" (giorno/mese)
    )

    # Valore minimo
    col7.metric("Valore minimo", f"{df_plot['valore'].min():.1f} µg/m³")

    # ── GRAFICO GIORNALIERO ───────────────────────────────────────────────────
    fig3, ax3 = plt.subplots(figsize=(12, 4))
    color = INQUINANTI_INFO.get(inq, {}).get("colore", "#3498db")

    # Linea principale: valore giornaliero
    ax3.plot(df_plot["data"], df_plot["valore"], color=color, linewidth=1.2,
             label=f"{inq} giornaliero")

    # Calcolo della soglia dei picchi: il 90° percentile
    # = il valore superato solo dal 10% dei giorni peggiori
    soglia = df_plot["valore"].quantile(0.90)

    # Selezioniamo solo i giorni con valore sopra la soglia
    picchi = df_plot[df_plot["valore"] >= soglia]

    # Disegniamo i picchi come puntini rossi sopra la linea
    ax3.scatter(picchi["data"], picchi["valore"],
                color="red", s=20, zorder=5,  # zorder=5 = disegnato sopra la linea
                label=f"Picchi (≥ p90: {soglia:.0f})")

    # Linea tratteggiata della media annuale (riferimento visivo)
    ax3.axhline(df_plot["valore"].mean(), color=color, linestyle="--",
                linewidth=1, alpha=0.6, label="Media annuale")

    ax3.set_ylabel("µg/m³")
    ax3.set_title(f"{inq} – {staz} – {anno_scelto}")
    ax3.legend(fontsize=9)
    ax3.grid(axis="y", alpha=0.3)
    plt.xticks(rotation=30)  # Date sull'asse X inclinate per non sovrapporsi
    plt.tight_layout()
    st.pyplot(fig3)
    plt.close()

    # ── ANALISI STAGIONALITÀ ──────────────────────────────────────────────────

    # Estraiamo il numero del mese da ogni data (es. gennaio = 1, febbraio = 2...)
    df_plot["mese"] = df_plot["data"].dt.month

    # Calcoliamo la media per ogni mese
    df_mese = df_plot.groupby("mese")["valore"].mean()

    # Troviamo il mese con la media più alta (il più critico)
    mese_peggiore = df_mese.idxmax()

    # Lista dei nomi dei mesi abbreviati (indice 0 = Gen, indice 1 = Feb...)
    nomi_mesi = ["Gen","Feb","Mar","Apr","Mag","Giu","Lug","Ago","Set","Ott","Nov","Dic"]

    # Calcoliamo la variabilità (deviazione standard = quanto i valori oscillano)
    variabilita = df_plot["valore"].std()

    # Se la variabilità è >40% della media, l'andamento è "molto variabile"
    commento_var = "molto variabile" if variabilita > df_plot["valore"].mean() * 0.4 else "abbastanza regolare"

    # Riquadro azzurro con l'analisi automatica
    st.info(
        f"🔍 **Analisi {anno_scelto}:** L'andamento è {commento_var} "
        f"(dev. standard: {variabilita:.1f} µg/m³). "
        f"Il mese più critico è stato **{nomi_mesi[mese_peggiore-1]}** "
        # mese_peggiore-1 perché la lista parte da 0 ma i mesi partono da 1
        f"con una media di {df_mese[mese_peggiore]:.1f} µg/m³. "
        + ("L'inquinante mostra una tipica stagionalità invernale. "
           if mese_peggiore in [1, 2, 11, 12] else          # Picco in inverno
           "L'inquinante raggiunge i picchi in estate (tipico per O₃ e O₃-precursori). "
           if mese_peggiore in [6, 7, 8] else "")           # Picco in estate
    )

    # ── GRAFICO MENSILE (NASCOSTO, SI APRE CON UN CLICK) ─────────────────────
    with st.expander("📊 Visualizza media mensile"):  # Sezione espandibile
        fig4, ax4 = plt.subplots(figsize=(8, 3))

        # Grafico a barre verticali, una per mese
        ax4.bar(
            nomi_mesi,                                    # Nomi mesi sull'asse X
            [df_mese.get(m, 0) for m in range(1, 13)],  # Valore medio per ogni mese (0 se manca)
            color=color, alpha=0.8
        )

        ax4.set_ylabel("µg/m³")
        ax4.set_title(f"Media mensile – {inq} @ {staz} – {anno_scelto}")
        ax4.grid(axis="y", alpha=0.3)
        plt.tight_layout()
        st.pyplot(fig4)
        plt.close()

st.divider()

# ══════════════════════════════════════════════════════════════════════════════
# FOOTER
# Piccola nota in fondo alla pagina con i riferimenti ai dati
# ══════════════════════════════════════════════════════════════════════════════

st.markdown(
    """
    <div style="text-align:center;color:#888;font-size:0.8em;margin-top:2em">
        Dati: <a href="https://dati.comune.milano.it" target="_blank">Portale Open Data – Comune di Milano</a>
        | ARPA Lombardia | Elaborazione propria
    </div>
    """,
    unsafe_allow_html=True,  # Permette HTML per il link cliccabile e il testo centrato
)