import streamlit as st

st.set_page_config ( page_title="Pericolosità Inquinanti Atmosferici")


inquinante_info = {
    "NO2": {
        "nome": "Biossido di azoto (NO₂)",
        "cos_e": "Gas prodotto dalla combustione: traffico, caldaie e attività industriali.",
        "perche": "Irrita le vie respiratorie e peggiora asma e bronchiti."
    },
    "PM10": {
        "nome": "Particolato PM10",
        "cos_e": "Particelle sospese  generate da traffico, polveri e riscaldamento.",
        "perche": "Può causare irritazioni, tosse e problemi respiratori."
    },
    "PM2.5": {
        "nome": "Particolato PM2.5",
        "cos_e": "Particelle molto fini  che restano a lungo nell’aria.",
        "perche": "Raggiungono gli alveoli e possono entrare nel sangue, aumentando i rischi cardiovascolari."
    }
}

st.title("Informazioni sugli Inquinanti Atmosferici")
st.write("Scegli un inquinante da analizzare.")


scelta = st.selectbox(
    "Inquinante:",
    list(inquinante_info.keys())
)

info = inquinante_info[scelta]

# Card semplice
st.markdown(
    f"""
    <div style="
        background-color:#eef3f5;
        padding:18px;
        border-radius:10px;
        border-left:5px solid #4CAF50;
        margin-top:15px;
    ">
        <h3 style="margin-top:0;">{info['nome']}</h3>
        <p><strong>Cos'è:</strong> {info['cos_e']}</p>
        <p><strong>Perché è dannoso:</strong> {info['perche']}</p>
    </div>
    """,
    unsafe_allow_html=True
)
