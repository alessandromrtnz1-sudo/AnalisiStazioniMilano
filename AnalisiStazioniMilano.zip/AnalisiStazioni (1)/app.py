"""
app.py – Monitoraggio Qualità dell'Aria di Milano
Applicazione Streamlit che analizza 10 anni di dati ARPA.
"""

import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import seaborn as sns
import json
from pathlib import Path

# ── Configurazione pagina ──────────────────────────────────────────────────────
st.set_page_config(
    page_title="Qualità dell'Aria – Milano",
    page_icon="🌬️",
    layout="wide",
)

# ── 1. DESCRIZIONE INQUINANTI ──────────────────────────────────────────────────
INQUINANTI_INFO = {
    "NO2": {
        "nome": "Biossido di azoto (NO₂)",
        "cos_e": "Gas rossastro prodotto dalla combustione: traffico (soprattutto diesel), riscaldamento e industria.",
        "pericoloso": "Irrita le vie respiratorie, aggrava asma e bronchiti. L'OMS fissa il limite annuale a 10 µg/m³.",
        "colore": "#e74c3c",
    },
    "PM10": {
        "nome": "Particolato PM10",
        "cos_e": "Particelle con diametro ≤ 10 µm: polveri stradali, scarichi, cantieri e pollini.",
        "pericoloso": "Si depositano nelle vie aeree superiori causando infiammazioni e peggiorando malattie cardiache.",
        "colore": "#e67e22",
    },
    "PM25": {
        "nome": "Particolato PM2.5",
        "cos_e": "Particelle finissime (≤ 2,5 µm) generate da combustioni incomplete e reazioni chimiche in atmosfera.",
        "pericoloso": "Penetrano fino agli alveoli e nel circolo sanguigno: aumentano il rischio di ictus e infarto.",
        "colore": "#8e44ad",
    },
    "O3": {
        "nome": "Ozono (O₃)",
        "cos_e": "Gas secondario formato dalla reazione di NOₓ e COV con la luce solare.",
        "pericoloso": "Irrita occhi e polmoni, riduce la capacità respiratoria. Più alto in estate e in periferia.",
        "colore": "#27ae60",
    },
    "SO2": {
        "nome": "Biossido di zolfo (SO₂)",
        "cos_e": "Gas pungente prodotto dalla combustione di combustibili fossili ricchi di zolfo.",
        "pericoloso": "Causa broncocostrizione acuta; contribuisce alle piogge acide.",
        "colore": "#2980b9",
    },
    "C6H6": {
        "nome": "Benzene (C₆H₆)",
        "cos_e": "Idrocarburo aromatico presente nei carburanti e nei fumi di scarico.",
        "pericoloso": "Cancerogeno accertato (gruppo 1 IARC); danneggia il midollo osseo.",
        "colore": "#16a085",
    },
    "CO_8h": {
        "nome": "Monossido di carbonio – media 8h (CO)",
        "cos_e": "Gas inodore prodotto da combustioni incomplete (traffico, stufe a legna).",
        "pericoloso": "Si lega all'emoglobina impedendo il trasporto di ossigeno; ad alte dosi è letale.",
        "colore": "#7f8c8d",
    },
}

# ── 2. CARICAMENTO DATI ────────────────────────────────────────────────────────
@st.cache_data(show_spinner="Caricamento dati in corso…")
def load_data():
    base = Path(__file__).parent / "dati"

    # ── Stazioni: usa il GeoJSON (contiene tutti gli ID 1-9) ──────────────────
    geo_path = base / "qaria_stazione.geojson"
    with open(geo_path, encoding="utf-8") as f:
        geo = json.load(f)

    stazioni_rows = []
    for feat in geo["features"]:
        p = feat["properties"]
        coords = feat["geometry"]["coordinates"]  # [lon, lat]
        stazioni_rows.append({
            "stazione_id": str(p["id_amat"]),
            "nome_stazione": p["nome"],
            "lon": coords[0],
            "lat": coords[1],
        })
    df_stazioni = pd.DataFrame(stazioni_rows)

    # ── Misurazioni: tutti i JSON nella cartella dati (escludi geojson/stazioni) ─
    skip = {"stazioni_aria.json", "qaria_stazione.geojson"}
    # Evita di caricare due volte il file 2021 duplicato
    seen_hashes: set = set()
    lista_df = []

    for fpath in sorted(base.glob("*.json")):
        if fpath.name in skip:
            continue
        try:
            with open(fpath, encoding="utf-8") as f:
                raw = json.load(f)
            temp = pd.DataFrame(raw)

            # Normalizzazione nomi colonne (versioni diverse del dataset)
            temp = temp.rename(columns={
                "id_stazione":      "stazione_id",
                "codice_stazione":  "stazione_id",
                "data_riferimento": "data",
                "data_misura":      "data",
                "valore_misura":    "valore",
                "inquinante_nome":  "inquinante",
            })

            # Colonne minime necessarie
            if not {"stazione_id", "data", "valore", "inquinante"}.issubset(temp.columns):
                continue

            temp = temp[["stazione_id", "data", "valore", "inquinante"]].copy()
            temp["stazione_id"] = temp["stazione_id"].astype(str)
            temp["valore"] = pd.to_numeric(temp["valore"], errors="coerce")
            temp["data"] = pd.to_datetime(temp["data"], errors="coerce")

            # De-duplicazione per file 2021 identici
            key = (len(temp), str(temp["data"].min()), str(temp["data"].max()))
            if key in seen_hashes:
                continue
            seen_hashes.add(key)

            lista_df.append(temp)
        except Exception as e:
            st.warning(f"Errore nel file {fpath.name}: {e}")

    if not lista_df:
        return None, None

    df = pd.concat(lista_df, ignore_index=True)
    df = df.dropna(subset=["data", "valore"])
    df["anno"] = df["data"].dt.year

    # Unione misurazioni ↔ stazioni (inner join su stazione_id)
    df_merged = pd.merge(df, df_stazioni, on="stazione_id", how="inner")

    return df_merged, df_stazioni


# ── Intestazione app ───────────────────────────────────────────────────────────
st.title("🌬️ Monitoraggio della Qualità dell'Aria – Milano")
st.caption(
    "Dati ARPA Lombardia / Comune di Milano • 2016-2025 • "
    "Stazioni di rilevamento comunali"
)

# ── Caricamento ───────────────────────────────────────────────────────────────
df, df_stazioni = load_data()

if df is None:
    st.error(
        "⚠️ Nessun dato trovato. Assicurati che i file JSON siano nella "
        "cartella `dati/` accanto ad `app.py`."
    )
    st.stop()

# ── Sidebar: filtri globali ────────────────────────────────────────────────────
st.sidebar.header("🔧 Filtri")
inquinanti_disponibili = sorted(df["inquinante"].unique())
inq = st.sidebar.selectbox("Inquinante", inquinanti_disponibili, index=inquinanti_disponibili.index("NO2") if "NO2" in inquinanti_disponibili else 0)

stazioni_disponibili = sorted(df["nome_stazione"].unique())
staz = st.sidebar.selectbox("Stazione", stazioni_disponibili)

st.sidebar.markdown("---")
st.sidebar.info(
    "I dati provengono dalle stazioni ARPA collocate nel territorio comunale di Milano. "
    "Non tutte le stazioni sono attive per tutti gli anni."
)

# ═══════════════════════════════════════════════════════════════════════════════
# SEZIONE 1 – Spiegazione inquinanti
# ═══════════════════════════════════════════════════════════════════════════════
st.header("📖 Cosa stai monitorando?")

info = INQUINANTI_INFO.get(inq)
if info:
    col_a, col_b = st.columns([1, 2])
    with col_a:
        st.markdown(
            f"""
            <div style="background:{info['colore']}22;border-left:6px solid {info['colore']};
                        padding:16px;border-radius:8px;">
                <h4 style="margin:0;color:{info['colore']}">{info['nome']}</h4>
                <p><strong>Cos'è:</strong> {info['cos_e']}</p>
                <p><strong>Perché è pericoloso:</strong> {info['pericoloso']}</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with col_b:
        # Riepilogo tutti gli inquinanti come tabella compatta
        st.markdown("**Riepilogo inquinanti monitorati**")
        rows = [
            {"Codice": k, "Nome": v["nome"].split("(")[0].strip(),
             "Principale fonte": v["cos_e"][:60] + "…"}
            for k, v in INQUINANTI_INFO.items()
        ]
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
else:
    st.info(f"Nessuna scheda descrittiva disponibile per **{inq}**.")

st.divider()

# ═══════════════════════════════════════════════════════════════════════════════
# SEZIONE 2 – Analisi temporale (10 anni)
# ═══════════════════════════════════════════════════════════════════════════════
st.header(f"📈 Andamento annuale – {inq} (tutte le stazioni)")

df_inq = df[df["inquinante"] == inq]
df_annuale = (
    df_inq.groupby("anno")["valore"]
    .agg(["mean", "min", "max"])
    .reset_index()
    .rename(columns={"mean": "Media", "min": "Min", "max": "Max"})
)

if df_annuale.empty:
    st.warning("Nessun dato disponibile per questo inquinante.")
else:
    col1, col2 = st.columns([3, 1])
    with col1:
        fig, ax = plt.subplots(figsize=(10, 4))
        color = INQUINANTI_INFO.get(inq, {}).get("colore", "#3498db")
        ax.fill_between(df_annuale["anno"], df_annuale["Min"], df_annuale["Max"],
                        alpha=0.15, color=color, label="Intervallo Min-Max")
        ax.plot(df_annuale["anno"], df_annuale["Media"],
                marker="o", color=color, linewidth=2.5, label="Media annuale")
        ax.set_xlabel("Anno")
        ax.set_ylabel("µg/m³")
        ax.set_title(f"Concentrazione media annuale di {inq} – Milano")
        ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))
        ax.legend()
        ax.grid(axis="y", alpha=0.3)
        st.pyplot(fig)
        plt.close()

    with col2:
        st.markdown("**Media per anno (µg/m³)**")
        st.dataframe(
            df_annuale[["anno", "Media"]].set_index("anno").style.format({"Media": "{:.1f}"}),
            use_container_width=True,
        )

    # Risposta automatica alle domande guida
    trend = df_annuale["Media"].iloc[-1] - df_annuale["Media"].iloc[0]
    anno_peggiore = df_annuale.loc[df_annuale["Media"].idxmax(), "anno"]
    st.info(
        f"📊 **Trend:** {'📉 In diminuzione' if trend < 0 else '📈 In aumento'} "
        f"di {abs(trend):.1f} µg/m³ dal {df_annuale['anno'].min()} al {df_annuale['anno'].max()}. "
        f"L'anno con il valore medio più alto è stato il **{anno_peggiore}**."
    )

st.divider()

# ═══════════════════════════════════════════════════════════════════════════════
# SEZIONE 3 – Classifica stazioni (media 10 anni)
# ═══════════════════════════════════════════════════════════════════════════════
st.header(f"🏭 Stazioni più critiche – {inq} (media 10 anni)")

df_classifica = (
    df_inq.groupby("nome_stazione")["valore"]
    .mean()
    .sort_values(ascending=False)
    .reset_index()
    .rename(columns={"valore": "Media µg/m³"})
)
df_classifica["Media µg/m³"] = df_classifica["Media µg/m³"].round(2)
df_classifica.index = range(1, len(df_classifica) + 1)

if df_classifica.empty:
    st.warning("Nessuna stazione ha dati validi per questo inquinante.")
else:
    col3, col4 = st.columns([1, 2])
    with col3:
        st.markdown("**Classifica completa**")
        st.dataframe(df_classifica, use_container_width=True)

    with col4:
        top5 = df_classifica.head(5)
        fig2, ax2 = plt.subplots(figsize=(7, 3.5))
        bars = ax2.barh(top5["nome_stazione"], top5["Media µg/m³"],
                        color=INQUINANTI_INFO.get(inq, {}).get("colore", "#e74c3c"),
                        edgecolor="white")
        ax2.invert_yaxis()
        ax2.set_xlabel("µg/m³")
        ax2.set_title(f"Top 5 stazioni più critiche – {inq}")
        ax2.bar_label(bars, fmt="%.1f", padding=3)
        ax2.grid(axis="x", alpha=0.3)
        plt.tight_layout()
        st.pyplot(fig2)
        plt.close()

st.divider()

# ═══════════════════════════════════════════════════════════════════════════════
# SEZIONE 4 – Andamento dell'ultimo anno per stazione selezionata
# ═══════════════════════════════════════════════════════════════════════════════
st.header(f"📅 Andamento giornaliero – {inq} @ {staz}")

subset = df[(df["nome_stazione"] == staz) & (df["inquinante"] == inq)]

if subset.empty:
    st.warning(
        f"⚠️ La stazione **{staz}** non ha dati per **{inq}**. "
        "Prova a selezionare una stazione o un inquinante diverso dalla barra laterale."
    )
else:
    ultimo_anno = int(subset["anno"].max())
    anni_disponibili = sorted(subset["anno"].unique(), reverse=True)

    anno_scelto = st.selectbox(
        "Anno da visualizzare",
        anni_disponibili,
        index=0,
        format_func=lambda x: f"{x} {'(più recente)' if x == ultimo_anno else ''}",
    )

    df_plot = subset[subset["anno"] == anno_scelto].sort_values("data")

    col5, col6, col7 = st.columns(3)
    col5.metric("Media annuale", f"{df_plot['valore'].mean():.1f} µg/m³")
    col6.metric("Valore massimo", f"{df_plot['valore'].max():.1f} µg/m³",
                f"il {df_plot.loc[df_plot['valore'].idxmax(), 'data'].strftime('%d/%m')}")
    col7.metric("Valore minimo", f"{df_plot['valore'].min():.1f} µg/m³")

    fig3, ax3 = plt.subplots(figsize=(12, 4))
    color = INQUINANTI_INFO.get(inq, {}).get("colore", "#3498db")

    # Linea + evidenziazione picchi (sopra 90° percentile)
    ax3.plot(df_plot["data"], df_plot["valore"], color=color, linewidth=1.2,
             label=f"{inq} giornaliero")
    soglia = df_plot["valore"].quantile(0.90)
    picchi = df_plot[df_plot["valore"] >= soglia]
    ax3.scatter(picchi["data"], picchi["valore"],
                color="red", s=20, zorder=5, label=f"Picchi (≥ p90: {soglia:.0f})")
    ax3.axhline(df_plot["valore"].mean(), color=color, linestyle="--",
                linewidth=1, alpha=0.6, label="Media annuale")
    ax3.set_ylabel("µg/m³")
    ax3.set_title(f"{inq} – {staz} – {anno_scelto}")
    ax3.legend(fontsize=9)
    ax3.grid(axis="y", alpha=0.3)
    plt.xticks(rotation=30)
    plt.tight_layout()
    st.pyplot(fig3)
    plt.close()

    # Analisi stagionalità
    df_plot["mese"] = df_plot["data"].dt.month
    df_mese = df_plot.groupby("mese")["valore"].mean()
    mese_peggiore = df_mese.idxmax()
    nomi_mesi = ["Gen","Feb","Mar","Apr","Mag","Giu","Lug","Ago","Set","Ott","Nov","Dic"]

    variabilita = df_plot["valore"].std()
    commento_var = "molto variabile" if variabilita > df_plot["valore"].mean() * 0.4 else "abbastanza regolare"

    st.info(
        f"🔍 **Analisi {anno_scelto}:** L'andamento è {commento_var} "
        f"(dev. standard: {variabilita:.1f} µg/m³). "
        f"Il mese più critico è stato **{nomi_mesi[mese_peggiore-1]}** "
        f"con una media di {df_mese[mese_peggiore]:.1f} µg/m³. "
        + ("L'inquinante mostra una tipica stagionalità invernale. "
           if mese_peggiore in [1, 2, 11, 12] else
           "L'inquinante raggiunge i picchi in estate (tipico per O₃ e O₃-precursori). "
           if mese_peggiore in [6, 7, 8] else "")
    )

    # Grafico mensile aggiuntivo
    with st.expander("📊 Visualizza media mensile"):
        fig4, ax4 = plt.subplots(figsize=(8, 3))
        ax4.bar(nomi_mesi, [df_mese.get(m, 0) for m in range(1, 13)],
                color=color, alpha=0.8)
        ax4.set_ylabel("µg/m³")
        ax4.set_title(f"Media mensile – {inq} @ {staz} – {anno_scelto}")
        ax4.grid(axis="y", alpha=0.3)
        plt.tight_layout()
        st.pyplot(fig4)
        plt.close()

st.divider()

# ═══════════════════════════════════════════════════════════════════════════════
# FOOTER
# ═══════════════════════════════════════════════════════════════════════════════
st.markdown(
    """
    <div style="text-align:center;color:#888;font-size:0.8em;margin-top:2em">
        Dati: <a href="https://dati.comune.milano.it" target="_blank">Portale Open Data – Comune di Milano</a>
        | ARPA Lombardia | Elaborazione propria
    </div>
    """,
    unsafe_allow_html=True,
)
